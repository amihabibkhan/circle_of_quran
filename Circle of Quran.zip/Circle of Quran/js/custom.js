$(function () {

    $('.all_slider').slick({
        arrows: true,
        nextArrow: '.slider_right',
        prevArrow: '.slider_left',
        infinite: true,
        autoplay: true,
        autoplaySpeed: 2000,
        //        fade: true,
        speed: 2000,
        dots: false,
        pauseOnHover: false,
        slidesToShow: 1,
        slidesToScroll: 1
    });

    $('.project_slider').slick({
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: true,
        speed:1000,
        autoplaySpeed: 2000,
        pauseOnHover:false,
        arrows: true,
        nextArrow:'.right',
        prevArrow:'.left',
        responsive: [
            {
                breakpoint: 500,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
    }
  ]
    });
    
//    venobox
    $('.venobox').venobox();






});
